# SENTINEL

**Sensor Network for Tracking, Integration, and Event Logging**

SENTINEL is the software of a surveillance operations centre. Four sensors send contact
reports to the centre, and SENTINEL collects them, records them, sorts them by importance, and
keeps one correct picture of the contacts. You build it in this repository, in C, for Linux:
one library in each lab of ECE 476 Engineering System Software (Fall 2026, University of
Victoria).

**Start with the Setup Guide**, [`docs/setup/setup.pdf`](docs/setup/setup.pdf). It sets up your
machine and your own private copy of this repository.

## The documents

| Document | Where | What it holds |
|---|---|---|
| Lab Documentation | the course gives it to you | The scenario: the detachment, the four sensors, the four parts of SENTINEL, and a user story |
| SENTINEL Lab Manual | [`docs/manual/sentinel_manual.pdf`](docs/manual/sentinel_manual.pdf) | The facts for all labs: the labs, the requirements, the repository, the given programs, the make targets |
| Setup Guide | [`docs/setup/setup.pdf`](docs/setup/setup.pdf) | Your machine, the tools, and your private copy of this repository |
| Submission Guide | [`docs/submit/submit.pdf`](docs/submit/submit.pdf) | The marks and the deadlines of each lab, the oral exam, the Lab 4 video, and how to hand in a lab |
| Lab 1 Brief | [`docs/lab1/lab1_brief.pdf`](docs/lab1/lab1_brief.pdf) | The contract of Lab 1 |
| Lab 1 Guide | [`docs/lab1/lab1_guide.pdf`](docs/lab1/lab1_guide.pdf) | The ideas behind Lab 1 |
| Lab 1 prelab | [`docs/lab1/prelab1.pdf`](docs/lab1/prelab1.pdf) | The questions to answer before the Lab 1 session |
| The page | [`web/README.md`](web/README.md) | The operations centre display |
| Lab 1 directory | [`src/libsyscall/README.md`](src/libsyscall/README.md) | The files that you write for Lab 1 |

When the course releases a later lab, its brief and its guide arrive in `docs/<lab>/`, with
`git pull upstream main`.

## Credit

The project brief and the scenario come from the ECE 476 Lab Documentation.
